package app.vidlii.mobile

import org.jsoup.Jsoup
import org.jsoup.nodes.Element

data class Video(
    val id: String,
    val title: String,
    val uploader: String,
    val duration: String,
    val thumb: String,
)

data class WatchInfo(val title: String, val streamUrl: String?, val pageUrl: String)

/**
 * ALL site-specific guesses live in this file. The parser is deliberately structural
 * (finds /watch?v= links and walks up to each card) rather than relying on class names,
 * but if VidLii changes its markup this is the only place to adjust.
 */
object Parser {
    private val idRe = Regex("""[?&]v=([A-Za-z0-9_-]{6,})""")
    private val durRe = Regex("""\b\d{1,2}:\d{2}(?::\d{2})?\b""")

    private fun idOf(href: String) = idRe.find(href)?.groupValues?.get(1)

    private fun idsIn(e: Element) =
        e.select("a[href*=watch?v=]").mapNotNull { idOf(it.attr("href")) }.toSet().size

    fun videos(html: String): List<Video> {
        val doc = Jsoup.parse(html, BASE)
        val out = LinkedHashMap<String, Video>()
        for (a in doc.select("a[href*=watch?v=]")) {
            val id = idOf(a.attr("href")) ?: continue
            if (id in out) continue

            // Walk up while the parent still contains only this one video: that's the card.
            var card: Element = a
            while (card.parent() != null && card.parent()!!.tagName() != "body" && idsIn(card.parent()!!) <= 1) {
                card = card.parent()!!
            }

            val img = card.selectFirst("img")
            val thumb = img?.let { it.attr("data-src").ifBlank { it.attr("src") } }.orEmpty()
            val title = card.select("a[href*=watch?v=]")
                .map { it.text().trim().ifBlank { it.attr("title").trim() } }
                .firstOrNull { it.isNotBlank() }
                ?: img?.attr("alt").orEmpty()
            if (title.isBlank() && thumb.isBlank()) continue

            out[id] = Video(
                id = id,
                title = title,
                uploader = card.selectFirst("a[href*=/user/]")?.text()?.trim().orEmpty(),
                duration = durRe.find(card.text())?.value.orEmpty(),
                thumb = if (thumb.isBlank()) "" else Net.abs(thumb),
            )
        }
        return out.values.toList()
    }

    fun watch(html: String, id: String): WatchInfo {
        val doc = Jsoup.parse(html, BASE)
        val title = doc.selectFirst("meta[property=og:title]")?.attr("content")
            ?: doc.selectFirst("h1")?.text()
            ?: doc.title()
        val stream = doc.selectFirst("video source[src]")?.attr("src")
            ?: doc.selectFirst("video[src]")?.attr("src")
            ?: doc.selectFirst("meta[property=og:video:url], meta[property=og:video]")?.attr("content")
            ?: Regex("""https?:\\?/\\?/[^"'\s<>]+?\.(?:mp4|m3u8)[^"'\s<>]*""")
                .find(html)?.value?.replace("\\/", "/")
        return WatchInfo(title.trim(), stream?.let { Net.abs(it) }, "$BASE/watch?v=$id")
    }
}

object Repo {
    suspend fun home() = Parser.videos(Net.get("$BASE/"))

    suspend fun search(q: String) =
        Parser.videos(Net.get("$BASE/results?search_query=" + java.net.URLEncoder.encode(q, "UTF-8")))

    suspend fun watch(id: String) = Parser.watch(Net.get("$BASE/watch?v=$id"), id)
}
