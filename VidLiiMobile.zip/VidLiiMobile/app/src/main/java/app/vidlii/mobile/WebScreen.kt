package app.vidlii.mobile

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp

/**
 * A short-lived WebView used ONLY for the things that genuinely need a real browser:
 *  - passing a Cloudflare check once (then cookies are shared with the native client)
 *  - signing in
 *  - the upload form (needs a file chooser + the site's own form handling)
 * It is created when this screen opens and destroyed when it closes, so no browser
 * engine or Cloudflare script keeps running while you browse the video list.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(url: String, title: String, autoCloseOnClear: Boolean, onDone: () -> Unit) {
    val holder = remember { arrayOf<ValueCallback<Array<Uri>>?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        holder[0]?.onReceiveValue(uri?.let { arrayOf(it) })
        holder[0] = null
    }
    var web: WebView? = null

    DisposableEffect(Unit) {
        onDispose {
            web?.apply { stopLoading(); loadUrl("about:blank"); (parent as? ViewGroup)?.removeView(this); destroy() }
            CookieManager.getInstance().flush()
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0E13))) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF1B2028)).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = onDone) { Text("Done") }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).also { w ->
                    web = w
                    w.settings.javaScriptEnabled = true
                    w.settings.domStorageEnabled = true
                    w.settings.userAgentString = Net.userAgent
                    CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                    w.webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(
                            v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
                        ): Boolean {
                            holder[0]?.onReceiveValue(null)
                            holder[0] = cb
                            picker.launch(arrayOf("video/*"))
                            return true
                        }
                    }
                    w.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView, u: String) {
                            CookieManager.getInstance().flush()
                            // Challenge solved: the real page's title no longer says "Just a moment".
                            if (autoCloseOnClear && !v.title.orEmpty().contains("moment", true)) onDone()
                        }
                    }
                    w.loadUrl(url)
                }
            }
        )
    }
}
