package app.vidlii.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Bg = Color(0xFF0B0E13)
private val Bar = Brush.verticalGradient(listOf(Color(0xFF2B323C), Color(0xFF1A1F26)))
private val Muted = Color(0xFFB6BDC6)
private val Accent = Color(0xFF8FA6C4)

sealed interface Screen {
    data class Feed(val query: String? = null) : Screen
    data class Watch(val id: String) : Screen
    data class Web(val url: String, val title: String, val autoClose: Boolean = false) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Root() }
    }
}

@Composable
fun Root() {
    val stack = remember { mutableStateListOf<Screen>(Screen.Feed()) }
    // Bumped whenever the WebView closes so feeds reload with fresh cookies (post-challenge / sign-in).
    var epoch by remember { mutableStateOf(0) }
    fun push(s: Screen) = stack.add(s)
    fun pop() { if (stack.size > 1) stack.removeLast() }

    BackHandler(enabled = stack.size > 1) { pop() }

    Box(Modifier.fillMaxSize().background(Bg)) {
        when (val s = stack.last()) {
            is Screen.Feed -> FeedScreen(
                query = s.query,
                epoch = epoch,
                onOpen = { push(Screen.Watch(it)) },
                onSearch = { push(Screen.Feed(it)) },
                onSignIn = { push(Screen.Web("$BASE/login", "Sign in")) },
                onUpload = { push(Screen.Web("$BASE/upload", "Upload")) },
                onChallenge = { push(Screen.Web(it, "Verify you're human", autoClose = true)) },
            )
            is Screen.Watch -> PlayerScreen(
                id = s.id,
                onChallenge = { push(Screen.Web(it, "Verify you're human", autoClose = true)) },
            )
            is Screen.Web -> WebScreen(s.url, s.title, s.autoClose) { epoch++; pop() }
        }
    }
}

@Composable
private fun TopBar(
    onSignIn: () -> Unit, onUpload: () -> Unit, onSearch: (String) -> Unit, showTools: Boolean = true,
) {
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    Row(
        Modifier.fillMaxWidth().background(Bar).padding(horizontal = 12.dp).height(56.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (searching) {
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search VidLii") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { if (q.isNotBlank()) onSearch(q.trim()) }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                ),
            )
        } else {
            Text("VidLii", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
        }
        if (showTools) {
            IconButton(onClick = onSignIn) { Icon(Icons.Default.Person, "Sign in", tint = Muted) }
            IconButton(onClick = onUpload) { Icon(Icons.Default.Add, "Upload", tint = Muted) }
        }
        IconButton(onClick = { searching = !searching }) { Icon(Icons.Default.Search, "Search", tint = Muted) }
    }
}

@Composable
fun FeedScreen(
    query: String?, epoch: Int,
    onOpen: (String) -> Unit, onSearch: (String) -> Unit,
    onSignIn: () -> Unit, onUpload: () -> Unit, onChallenge: (String) -> Unit,
) {
    var videos by remember { mutableStateOf<List<Video>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var challengeUrl by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableStateOf(0) }

    LaunchedEffect(query, epoch, retry) {
        videos = null; error = null; challengeUrl = null
        try {
            videos = if (query == null) Repo.home() else Repo.search(query)
        } catch (c: ChallengeException) {
            challengeUrl = c.url
        } catch (e: Exception) {
            error = e.message ?: "Couldn't load"
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(onSignIn, onUpload, onSearch)
        val label = if (query == null) "Recommended Videos" else "Search: $query"
        when {
            challengeUrl != null -> Centered {
                Text("VidLii wants a quick browser check.", color = Color.White)
                TextButton(onClick = { onChallenge(challengeUrl!!) }) { Text("Verify once") }
            }
            error != null -> Centered {
                Text(error!!, color = Muted)
                TextButton(onClick = { retry++ }) {
                    Text("Retry")
                }
            }
            videos == null -> Centered { CircularProgressIndicator(color = Accent) }
            videos!!.isEmpty() -> Centered { Text("No videos found", color = Muted) }
            else -> LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(videos!!, key = { it.id }) { VideoRow(it, label, onOpen) }
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) =
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) { content() }

@Composable
private fun VideoRow(v: Video, source: String, onOpen: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen(v.id) }) {
        Box(Modifier.width(112.dp).height(84.dp).background(Color(0xFF1B2028))) {
            AsyncImage(
                model = v.thumb.ifBlank { null }, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
            if (v.duration.isNotBlank()) {
                Text(
                    v.duration, color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xCC000000))
                        .padding(horizontal = 3.dp),
                )
            }
        }
        Column(Modifier.padding(start = 8.dp).weight(1f)) {
            Text(v.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 3)
            if (v.uploader.isNotBlank()) Text("by ${v.uploader}", color = Muted, fontSize = 14.sp)
            Text("from $source", color = Muted, fontSize = 14.sp)
        }
    }
}
