package app.vidlii.mobile

import android.app.Application
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebSettings
import coil.ImageLoader
import coil.ImageLoaderFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

const val BASE = "https://www.vidlii.com"

/** Thrown when Cloudflare serves an interactive challenge instead of the page. */
class ChallengeException(val url: String) : Exception("Verification needed")

class VidliiApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Net.init(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this).okHttpClient { Net.client }.crossfade(true).build()
}

/**
 * Shares cookies with the system WebView. When the user passes a Cloudflare check or signs in
 * inside the WebView screen, the resulting cookies (cf_clearance, session) are used by all
 * native requests automatically, so the WebView never has to stay alive in the background.
 */
private class WebViewCookieJar : CookieJar {
    private val cm get() = CookieManager.getInstance()

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        cookies.forEach { cm.setCookie(url.toString(), it.toString()) }
        cm.flush()
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> =
        cm.getCookie(url.toString())
            ?.split(";")
            ?.mapNotNull { Cookie.parse(url, it.trim()) }
            ?: emptyList()
}

object Net {
    lateinit var client: OkHttpClient
        private set

    /** Must match the WebView's UA: Cloudflare ties cf_clearance to it. */
    lateinit var userAgent: String
        private set

    // Tiny in-memory page cache so back-navigation and re-renders never refetch.
    private val pageCache = HashMap<String, Pair<Long, String>>()
    private const val TTL_MS = 2 * 60 * 1000L

    fun init(ctx: Context) {
        userAgent = WebSettings.getDefaultUserAgent(ctx)
        CookieManager.getInstance().setAcceptCookie(true)
        client = OkHttpClient.Builder()
            .cookieJar(WebViewCookieJar())
            .cache(Cache(File(ctx.cacheDir, "http"), 30L * 1024 * 1024))
            .dispatcher(Dispatcher().apply {
                maxRequests = 4
                maxRequestsPerHost = 2          // be gentle with the server
            })
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", userAgent)
                        .header("Accept-Language", "en-US,en;q=0.9")
                        .build()
                )
            }
            .build()
    }

    fun abs(path: String): String = when {
        path.startsWith("http") -> path
        path.startsWith("//") -> "https:$path"
        path.startsWith("/") -> BASE + path
        else -> "$BASE/$path"
    }

    suspend fun get(url: String, useCache: Boolean = true): String = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (useCache) pageCache[url]?.let { (t, body) -> if (now - t < TTL_MS) return@withContext body }

        var attempt = 0
        while (true) {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                val body = r.body?.string().orEmpty()
                val challenged = (r.code == 403 || r.code == 503) &&
                    (r.header("cf-mitigated") == "challenge" ||
                        body.contains("Just a moment", ignoreCase = true) ||
                        body.contains("challenge-platform"))
                if (challenged) throw ChallengeException(url)

                if (r.code == 429 && attempt < 2) {
                    // Back off instead of hammering the server.
                    val wait = r.header("Retry-After")?.toLongOrNull() ?: (2L shl attempt)
                    attempt++
                    delay(wait.coerceAtMost(15) * 1000)
                } else {
                    if (!r.isSuccessful) error("HTTP ${r.code}")
                    pageCache[url] = now to body
                    return@withContext body
                }
            }
        }
        @Suppress("UNREACHABLE_CODE") ""
    }
}
