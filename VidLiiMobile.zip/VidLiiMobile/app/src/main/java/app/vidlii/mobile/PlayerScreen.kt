package app.vidlii.mobile

import android.view.ViewGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@Composable
fun PlayerScreen(id: String, onChallenge: (String) -> Unit) {
    val ctx = LocalContext.current
    val uriHandler = LocalUriHandler.current
    var info by remember { mutableStateOf<WatchInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        try { info = Repo.watch(id) }
        catch (c: ChallengeException) { onChallenge(c.url) }
        catch (e: Exception) { error = e.message }
    }

    val player = remember {
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(OkHttpDataSource.Factory(Net.client)))
            .build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(info) {
        info?.streamUrl?.let { player.setMediaItem(MediaItem.fromUri(it)); player.prepare(); player.playWhenReady = true }
    }

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxWidth().aspectRatio(16 / 9f),
            factory = { c ->
                PlayerView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(-1, -1)
                    this.player = player
                }
            },
        )
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when {
                error != null -> Text(error!!, color = Color(0xFFB6BDC6))
                info == null -> CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
                else -> {
                    Text(info!!.title, color = Color.White, fontWeight = FontWeight.Bold)
                    if (info!!.streamUrl == null) {
                        Text("Couldn't find a direct video stream on this page.", color = Color(0xFFB6BDC6))
                        TextButton(onClick = { uriHandler.openUri(info!!.pageUrl) }) { Text("Open in browser") }
                    }
                }
            }
        }
    }
}
