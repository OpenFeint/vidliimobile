# VidLii Mobile (Android)

Native Kotlin / Jetpack Compose client styled after your screenshot: dark list, thumbnail with duration badge,
bold title, "by uploader", "from Recommended Videos", and the person / upload / search icons in the header.

## Open and run
1. Open this folder in Android Studio (Koala or newer). It will create the Gradle wrapper and sync.
2. Run on a device or emulator (minSdk 24).

## How it avoids the Cloudflare resource hog
- Browsing, search and playback are **native** (OkHttp + Jsoup + ExoPlayer). No WebView is running on the list pages,
  so there is no Cloudflare JavaScript executing in the background.
- A short-lived WebView opens only for: sign-in, upload, and a one-time "Verify once" check if Cloudflare asks
  for it. It is destroyed when you tap Done.
- Cookies are shared between that WebView and the native client (`Net.kt`), and the User-Agent matches, so a
  passed check or a login carries over to native requests.
- Requests are polite: max 2 per host, 30 MB HTTP cache, 2-minute in-memory page cache, and back-off on HTTP 429.
- This does not bypass or spoof Cloudflare. When a challenge appears, you complete it normally in the WebView.

## Sign-in and upload
Both use the site's own pages inside the temporary WebView (`/login`, `/upload`), so VidLii's real forms,
CSRF handling and file validation are used. The upload screen supports the file picker for choosing a video.

## Things to verify (I couldn't reach the site from my environment)
- Page structure: `Parser.kt` finds `/watch?v=` links structurally, then reads thumbnail, title, uploader (`/user/`)
  and duration from each card. If a list comes up empty, adjust that file only.
- URLs assumed: `/` (home), `/results?search_query=`, `/watch?v=`, `/login`, `/upload`.
- Playback looks for a `<video>` source, `og:video`, or a `.mp4`/`.m3u8` URL in the page; otherwise it offers
  "Open in browser".
- Check VidLii's terms and robots rules before publishing the app, and consider asking the site owner.
